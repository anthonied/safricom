﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Safricom.Controllers
{
	public class JavascriptTestsController : Controller
	{
		//
		// GET: /JavascriptTests/

		public ActionResult Index()
		{
			return View();
		}

		public ActionResult Home_Index()
		{
			return View();
		}
		/*
				//
				// GET: /JavascriptTests/Details/5

				public ActionResult Details(int id)
				{
					return View();
				}

				//
				// GET: /JavascriptTests/Create

				public ActionResult Create()
				{
					return View();
				}

				//
				// POST: /JavascriptTests/Create

				[HttpPost]
				public ActionResult Create(FormCollection collection)
				{
					try
					{
						// TODO: Add insert logic here

						return RedirectToAction("Index");
					}
					catch
					{
						return View();
					}
				}

				//
				// GET: /JavascriptTests/Edit/5

				public ActionResult Edit(int id)
				{
					return View();
				}

				//
				// POST: /JavascriptTests/Edit/5

				[HttpPost]
				public ActionResult Edit(int id, FormCollection collection)
				{
					try
					{
						// TODO: Add update logic here

						return RedirectToAction("Index");
					}
					catch
					{
						return View();
					}
				}

				//
				// GET: /JavascriptTests/Delete/5

				public ActionResult Delete(int id)
				{
					return View();
				}

				//
				// POST: /JavascriptTests/Delete/5

				[HttpPost]
				public ActionResult Delete(int id, FormCollection collection)
				{
					try
					{
						// TODO: Add delete logic here

						return RedirectToAction("Index");
					}
					catch
					{
						return View();
					}
				}
		*/
	}
}
